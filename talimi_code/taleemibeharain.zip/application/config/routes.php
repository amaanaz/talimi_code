<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller']                                = 'home';
$route['404_override']                                      = '';
$route['translate_uri_dashes']                              = FALSE;

$route['test_home']                                         = 'home/testHome';
$route['faq']                                               = 'home/faq';
$route['plans']                                             = 'home/plans';
$route['contact_us']                                        = 'home/contact_us';
$route['login']                                             = 'home/login';
$route['registration']                                      = 'home/registration';