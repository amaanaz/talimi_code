<!DOCTYPE html>
<html lang="en">
<?php $this->load->view('template/head') ?>

<body class="hold-transition layout-top-nav">
    <div class="wrapper">
        <?php $this->load->view('template/navTop') ?>
        <div class="content-wrapper">
            <div class="content">
                <?php $this->load->view($content); ?>
            </div>
        </div>
    </div>
    <?php $this->load->view('template/footer') ?>
    </div>
    <?php $this->load->view('template/scripts') ?>
</body>

</html>