  <footer class="main-footer">
      <div class="float-right d-none d-sm-inline">
          <!-- Developed By -->
      </div>
      <strong>Copyright &copy; 2021-2024 <a href="#">ValueTech</a>.</strong> All rights reserved.
  </footer>