<div class="footer">
    <div class="container">
        <div class="agile-footer-grids">
            <div class="col-md-6 agile-footer-grid">
                <h4>Twitter <span>Posts</span></h4>
                <ul class="w3agile_footer_grid_list">
                    <li>Ut aut reiciendis voluptatibus maiores <a href="#">http://example.com</a> alias, ut aut reiciendis.
                    </li>
                    <li>Itaque earum rerum hic tenetur a sapiente delectus <a href="#">http://example.com</a> ut aut
                        voluptatibus.</li>
                </ul>
            </div>
            <div class="col-md-6 agile-footer-grid">
                <h4>Quick <span>Links</span></h4>
                <div class="popular-grids">
                <ul class="w3agile_footer_grid_list">
                    <li>Ut aut reiciendis voluptatibus maiores <a href="#">http://example.com</a> alias, ut aut reiciendis.
                        
                    </li>
                    <li>Itaque earum rerum hic tenetur a sapiente delectus <a href="#">http://example.com</a> ut aut
                        voluptatibus.</li>
                </ul>
                </div>
                
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>  
</div>