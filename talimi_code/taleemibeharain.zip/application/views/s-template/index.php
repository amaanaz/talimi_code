<!DOCTYPE html>
<html lang="en">
<?php $this->load->view('s-template/head') ?>

<body >
    <!-- header-top -->
    <?php $this->load->view('s-template/navHeader') ?>
    <!-- //header-top -->
    <!-- header -->
    <?php $this->load->view('s-template/navTop') ?>

    <!-- //header -->
    <!-- banner -->
    <div class="main">
        <div class="page_container">
            <div id="immersive_slider">
                <div class="slide" data-blurred="">
                    <div class="col-md-6 image">
                        <img src="<?php echo base_url('assets/') ?>images/3a.jpg" alt="Slider 1" />
                    </div>
                    <div class="col-md-6 content">
                        <h3>Schooly <span></span></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed efficitur velit ac fringilla fermentum. Nulla sodales, magna eget pharetra feugiat, tellus metus lacinia nunc, nec vulputate purus nisl nec tortor. Mauris sem diam, interdum a euismod vitae, viverra non sapien. </p>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="slide" data-blurred="">
                    <div class="col-md-6 image">
                        <img src="<?php echo base_url('assets/') ?>images/1a.jpg" alt="Slider 1" />
                    </div>
                    <div class="col-md-6 content">
                        <h3>Haflathy <span></span></h3>
                        <p>Donec sagittis, dui sed lobortis convallis, ante eros auctor leo, vel commodo lacus nisl vitae velit. Nulla facilisi. Integer vehicula porta urna, id lacinia nisl semper vel. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. </p>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="slide" data-blurred="">
                    <div class="col-md-6 image">
                        <img src="<?php echo base_url('assets/') ?>images/2a.jpg" alt="Slider 1" />
                    </div>
                    <div class="col-md-6 content">
                        <h3>Hometime <span></span></h3>
                        <p>Aliquam at efficitur odio, et commodo odio. Nulla est lectus, tristique sit amet lorem at, porttitor dapibus nisi. Quisque bibendum sem ut ex pharetra sagittis. Vestibulum eu sapien non purus interdum tempus. Aenean varius elit sit amet lorem ultrices, at iaculis velit sodales. </p>
                    </div>
                    <div class="clearfix"> </div>
                </div>

                <a href="#" class="is-prev">&laquo;</a>
                <a href="#" class="is-next">&raquo;</a>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#immersive_slider").immersive_slider({
                container: ".main"
            });
        });
    </script>
    <!-- //banner -->
    <!-- banner-bottom -->
    <div class="banner-bottom">
        <div class="container">
            <div class="w3-banner-bottom-heading">
                <h3>What <span>We Do?</span></h3>
            </div>
            <div class="agileits-banner-bottom">
                <div class="col-md-3 agileits-banner-bottom-grid">
                    <div class="services-grid1">
                        <div class="services-grid-right agile-services-grid-right">
                            <div class="services-grid-right-grid hvr-radial-out blue-grid">
                                <span class="glyphicon glyphicon-grain" aria-hidden="true"></span>
                            </div>
                        </div>
                        <div class="services-grid-left agile-services-grid-left">
                            <h4>repreh qui in ea voluptate</h4>
                            <p>Itaque earum rerum hic tenetur a sapiente
                                delectus, ut aut reiciendis voluptatibus maiores alias</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 agileits-banner-bottom-grid">
                    <div class="services-grid1">
                        <div class="services-grid-right agile-services-grid-right">
                            <div class="services-grid-right-grid hvr-radial-out orange-grid">
                                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                            </div>
                        </div>
                        <div class="services-grid-left agile-services-grid-left">
                            <h4>repreh qui in ea voluptate</h4>
                            <p>Itaque earum rerum hic tenetur a sapiente
                                delectus, ut aut reiciendis voluptatibus maiores alias</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 agileits-banner-bottom-grid">
                    <div class="services-grid1">
                        <div class="services-grid-right agile-services-grid-right">
                            <div class="services-grid-right-grid hvr-radial-out green-grid">
                                <span class="glyphicon glyphicon-magnet" aria-hidden="true"></span>
                            </div>
                        </div>
                        <div class="services-grid-left agile-services-grid-left">
                            <h4>repreh qui in ea voluptate</h4>
                            <p>Itaque earum rerum hic tenetur a sapiente
                                delectus, ut aut reiciendis voluptatibus maiores alias</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 agileits-banner-bottom-grid">
                    <div class="services-grid1">
                        <div class="services-grid-right agile-services-grid-right">
                            <div class="services-grid-right-grid hvr-radial-out red-grid">
                                <span class="glyphicon glyphicon-stats" aria-hidden="true"></span>
                            </div>
                        </div>
                        <div class="services-grid-left agile-services-grid-left">
                            <h4>repreh qui in ea voluptate</h4>
                            <p>Itaque earum rerum hic tenetur a sapiente
                                delectus, ut aut reiciendis voluptatibus maiores alias</p>
                        </div>
                    </div>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
    <!-- //banner-bottom -->
    <!-- special -->
    <div class="special">
        <div class="container">
            <div class="w3-banner-bottom-heading">
                <h3>Our <span>Plans</span></h3>
            </div>
            <div class="wthree-special-grid">
            <div class="row">
        <div class="col-md-4 col-sm-6">
            <div class="pricingTable10">
                <div class="pricingTable-header">
                    <h3 class="heading">School Plan I</h3>
                    <img src="<?php echo base_url('assets/images/') ?>school.png" />
                </div>
                <div class="pricing-content">
                    <ul>
                        <li>Schooly</li>
                        <!-- <li>50 Email Accounts</li>
                        <li>50GB Monthly Bandwidth</li>
                        <li>10 Subdomains</li>
                        <li>15 Domains</li> -->
                    </ul>
                    <a href="#" class="read">Get Quote</a>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div class="pricingTable10">
                <div class="pricingTable-header">
                    <h3 class="heading">Parent Plan I</h3>
                    <img src="<?php echo base_url('assets/images/') ?>family.png" />
                </div>
                <div class="pricing-content">
                    <ul>
                        <li>Schooly</li>
                        <li>Hometime</li>
                        <li>Yearly Subscription</li>
                        <!-- <li>15 Subdomains</li>
                        <li>20 Domains</li> -->
                    </ul>
                    <a href="#" class="read">Subscribe Now</a>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div class="pricingTable10">
                <div class="pricingTable-header">
                    <h3 class="heading">Parent Plan II</h3>
                    <span class="price-value">
                        <span class="currency">BD</span> 12
                        <span class="month">/student</span>
                    </span>
                </div>
                <div class="pricing-content">
                    <ul>
                        <li>Hafilaty</li>
                        <li>Yearly Subscription</li>
                        <!-- <li>70GB Monthly Bandwidth</li>
                        <li>20 Subdomains</li>
                        <li>25 Domains</li> -->
                    </ul>
                    <a href="#" class="read">Subscribe Now</a>
                </div>
            </div>
        </div>
    </div>
            </div>
        </div>
    </div>
    <!-- //special -->
    <!-- choose -->
    <div class="choose jarallax">
        <div class="w3-agile-testimonial">
            <div class="container-fluid">
                <div class="w3-agileits-choose">
                    <div class="col-md-4 choose-grid">
                        <div class="w3-banner-bottom-heading choose-heading">
                            <h3>How <span> Schooly</span> works?</h3>
                        </div>
                        <div class="top-choose-info testimonial-info">
                        <video style="width: 100%; height: 100%" controls>
                            <source src="<?php echo base_url('assets/video2.mp4')?>" type="video/mp4">
                        </video>
                        </div>
                    </div>
                    <div class="col-md-4 choose-grid">
                        <div class="w3-banner-bottom-heading choose-heading">
                            <h3>How<span> Hafilaty</span> works?</h3>
                        </div>
                        <div class="top-choose-info testimonial-info">

                        <video style="width: 100%; height: 100%" controls>
                            <source src="<?php echo base_url('assets/video3.mp4')?>" type="video/mp4">
                        </video>
                        </div>
                    </div>
                    <div class="col-md-4 choose-grid">
                        <div class="w3-banner-bottom-heading choose-heading">
                            <h3>How<span> Hometime</span> works?</h3>
                        </div>
                        <div class="top-choose-info testimonial-info">

                        <video style="width: 100%; height: 100%" controls>
                            <source src="<?php echo base_url('assets/video3.mp4')?>" type="video/mp4">
                        </video>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </div>
    </div>
    <!-- //choose -->
    <!-- subscribe -->
    <div class="subscribe">
        <div class="container">
            <div class="w3-banner-bottom-heading">
                <h3>Happy<span> customers</span></h3>
            </div>
            <div class="w3-agile-subscribe-form">
                <!-- <form action="#" method="post">
                    <input type="text" placeholder="Email" name="Email" required="">
                    <button class="btn1">Subscribe</button>
                </form> -->
            </div>
        </div>
    </div>
    <!-- //subscribe -->
    <?php $this->load->view('s-template/footer') ?>
    <?php $this->load->view('s-template/scripts') ?>
</body>

</html>