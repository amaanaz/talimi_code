    <div class="header-top">
        <div class="container">
            <div class="w3layouts-address">
                <ul>
                    <li><i class="fa fa-mobile" aria-hidden="true"></i> +11 222 333 4444</li>
                    <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a href="mailto:info@example.com"> mail@example.com</a></li>
                </ul>
            </div>
            <div class="agileinfo-social-grids">
                <ul>
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li>
                        <a href="#" class="dropdown-toggle tt" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <i class="fa fa-language text-white"></i> <p class="hdtext hide">Arabic</p>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="hvr-sweep-to-bottom" href="login.html">English</a></li>
                            <li><a class="hvr-sweep-to-bottom" href="registration.html">Arabic</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>