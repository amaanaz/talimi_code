<div class="header">
    <div class="container">
        <nav class="navbar navbar-default">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="w3layouts-logo">
                    <h1><a href="<?php echo base_url('') ?>"><img src="<?php echo base_url('assets/images/logo.png') ?>" /></a></h1>
                </div>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
                <nav>
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="<?php echo base_url('') ?>">Home</a></li>
                        <li><a href="<?php echo base_url('') ?>" class="hvr-sweep-to-bottom">FAQs</a></li>
                        <li><a href="<?php echo base_url('') ?>" class="hvr-sweep-to-bottom">Plans</a></li>
                        <li><a href="<?php echo base_url('') ?>" class="hvr-sweep-to-bottom">Contact Us</a></li>
                        <li><a href="<?php echo base_url('') ?>" class="hvr-sweep-to-bottom">Login</a></li>
                        <li><a href="<?php echo base_url('') ?>" class="hvr-sweep-to-bottom">Registration</a></li>
                    </ul>
                </nav>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
    </div>
</div>