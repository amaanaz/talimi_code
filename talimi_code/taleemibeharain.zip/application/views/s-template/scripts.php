<!-- //footer -->
<script src="<?php echo base_url('assets/') ?>js/jarallax.js"></script>
<script type="text/javascript">
    /* init Jarallax */
    $('.jarallax').jarallax({
        speed: 0.5,
        imgWidth: 1366,
        imgHeight: 768
    })
</script>
<script src="<?php echo base_url('assets/') ?>js/responsiveslides.min.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/') ?>js/move-top.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/') ?>js/easing.js"></script>
<!-- here stars scrolling icon -->
<script type="text/javascript">
    $(document).ready(function() {
        /*
        	var defaults = {
        	containerID: 'toTop', // fading element id
        	containerHoverID: 'toTopHover', // fading element hover id
        	scrollSpeed: 1200,
        	easingType: 'linear' 
        	};
        */

        $().UItoTop({
            easingType: 'easeOutQuart'
        });

    });
</script>
<!-- //here ends scrolling icon -->
<!-- pricing -->
<script src="<?php echo base_url('assets/') ?>js/jquery.flipster.js"></script>
<script>
    $(function() {
        $(".flipster").flipster({
            style: 'flat',
            spacing: -0.25

        });
    });
    
$(window).scroll(function(){
    if ($(window).scrollTop() >= 1) {
        $('.header').addClass('fixed-header');
        // $('nav div').addClass('visible-title');
    }
    else {
        $('.header').removeClass('fixed-header');
        // $('nav div').removeClass('visible-title');
    }
});

</script>
<!-- //pricing -->
<!-- slider -->
<script type="text/javascript" src="<?php echo base_url('assets/') ?>js/jquery.immersive-slider.js"></script>
<!-- //slider -->