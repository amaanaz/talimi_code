<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Value Tech | Home Page</title>

    <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/custom.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/font-awesome.css">
    <!-- font -->
    <link href="//fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
    <link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css'>

    <script src="<?php echo base_url('assets/'); ?>js/jquery-1.11.1.min.js"></script>
    <script src="<?php echo base_url('assets/'); ?>js/bootstrap.js"></script>
    <script src="<?php echo base_url('assets/'); ?>js/SmoothScroll.min.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event) {
                event.preventDefault();
                $('html,body').animate({
                    scrollTop: $(this.hash).offset().top
                }, 1000);
            });
        });
    </script>
    <link href='<?php echo base_url('assets/'); ?>css/immersive-slider.css' rel='stylesheet' type='text/css'>
    <!-- pricing -->
    <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/jquery.flipster.css">
</head>