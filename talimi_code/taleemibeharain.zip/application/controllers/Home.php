<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	
    public function __construct()
    {
        parent::__construct();
    }

	public function index()
	{
		$data['page_name']="Home Page";
		$data['content']="home-pages/home_page";
		$this->load->view('template/index',$data);
	}
	public function testHome()
	{
		$data['page_name']="Home Page";
		$data['content']="home-pages/home_page";
		$this->load->view('s-template/index',$data);
	}
	public function faq()
	{
		$data['page_name']="FAQ";
		$data['content']="home-pages/faq";
		$this->load->view('s-template/index',$data);
	}
	public function plans()
	{
		$data['page_name']="Plans";
		$data['content']="home-pages/plans";
		$this->load->view('s-template/index',$data);
	}
	public function contact_us()
	{
		$data['page_name']="Contact Us";
		$data['content']="home-pages/contact_us";
		$this->load->view('s-template/index',$data);
	}
	public function login()
	{
		$data['page_name']="Login";
		$data['content']="home-pages/login";
		$this->load->view('s-template/index',$data);
	}
	public function registration()
	{
		$data['page_name']="Registration";
		$data['content']="home-pages/registration";
		$this->load->view('s-template/index',$data);
	}
}
